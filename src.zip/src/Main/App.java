
package Main;

import Model.Producto;


public class App {
    public static void main(String[] args) {
    
    Producto cafe = new Producto("P01", "Café", "Bebida", 1200, 50);
    
        
        
    }
}
