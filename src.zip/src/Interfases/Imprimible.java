
package Interfases;

public interface Imprimible {

    String generarImpresion();
}

