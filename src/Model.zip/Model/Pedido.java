
package Model;

public class Pedido {
    
}
